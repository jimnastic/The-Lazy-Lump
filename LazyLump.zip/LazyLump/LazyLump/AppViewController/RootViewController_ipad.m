//
//  RootViewController.m
//
//  Created by Darji Mehul iMobDev on 20/01/12.
//  Copyright (c) 2012 iMobDev Tech. All rights reserved.
//

#import "RootViewController_ipad.h"
#import "KTOneFingerRotationGestureRecognizer.h"
@implementation RootViewController_ipad
@synthesize spinwhell,swipeLeftRecognizer;
@synthesize rotation;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    //    [self addRotationGestureToView:spinwhell];
}

//- (void)addRotationGestureToView:(UIImageView *)view
//{
//    KTOneFingerRotationGestureRecognizer *rotation = [[KTOneFingerRotationGestureRecognizer alloc] initWithTarget:self action:@selector(rotating:)];
//    [view addGestureRecognizer:rotation];
//    [rotation release];
//}
- (void)rotating:(UIImageView * )recognizer
{
    //    UIView *view = [recognizer view];
    [recognizer setTransform:CGAffineTransformRotate([recognizer transform], [self rotation])];
    //    NSLog(@"rotation:%f",recognizer.rotation);
}

- (void)viewDidUnload
{
    [self setSpinwhell:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

-(void)animation{
    //    [[spinwhell layer] addAnimation:[self rotateanimation:1.0] forKey:@"Clockwise"];
    //    [CATransaction commit];
}
- (void)animationDidStop:(CAAnimation *)theAnimation finished:(BOOL)flag
{
//    [CATransaction begin];
//    [CATransaction setValue:(id)kCFBooleanFalse forKey:kCATransactionDisableActions];
//    [CATransaction setValue:[NSNumber numberWithFloat:speed] forKey:kCATransactionAnimationDuration];
//    animation = [CABasicAnimation animationWithKeyPath:@"transform.rotation.z"];
//	//animation.delegate=self;
//    animation.fromValue = [NSNumber numberWithFloat:0.0];
//    animation.toValue = [NSNumber numberWithFloat:2 * M_PI];
////    animation.repeatCount=1;
//    animation.timingFunction = [CAMediaTimingFunction functionWithName: kCAMediaTimingFunctionEaseInEaseOut];
//    animation.delegate = nil;
//    [[spinwhell layer]addAnimation:animation forKey:@"ClockWise1"];
//    [CATransaction  commit];
}
-(id)rotateanimation:(float)timeDuration                        //wheel rotation animation
{
	[CATransaction begin];
    [CATransaction setValue:(id)kCFBooleanFalse forKey:kCATransactionDisableActions];
    [CATransaction setValue:[NSNumber numberWithFloat:timeDuration] forKey:kCATransactionAnimationDuration];
    animation = [CABasicAnimation animationWithKeyPath:@"transform.rotation.z"];
	//animation.delegate=self;
    animation.fromValue = [NSNumber numberWithFloat:0.0];
    animation.toValue = [NSNumber numberWithFloat:2 * M_PI];
    animation.repeatCount=5;
    animation.timingFunction = [CAMediaTimingFunction functionWithName: kCAMediaTimingFunctionLinear];
    animation.delegate = self;
	return animation;
}
-(id)Anticlockrotateanimation:(float)timeDuration                        //wheel rotation animation
{
	[CATransaction begin];
    [CATransaction setValue:(id)kCFBooleanFalse forKey:kCATransactionDisableActions];
    [CATransaction setValue:[NSNumber numberWithFloat:timeDuration] forKey:kCATransactionAnimationDuration];
    animation = [CABasicAnimation animationWithKeyPath:@"transform.rotation.z"];
	//animation.delegate=self;
    animation.repeatCount=5;
    animation.fromValue = [NSNumber numberWithFloat:0.0];
    animation.toValue = [NSNumber numberWithFloat:-2 * M_PI];
    animation.timingFunction = [CAMediaTimingFunction functionWithName: kCAMediaTimingFunctionLinear];
    animation.delegate = self;
	return animation;
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event 
{    
    previousTimestamp = event.timestamp;
}
- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
    UITouch *touch = [touches anyObject];
    if (touch.view==spinwhell)
    {
        CGPoint location = [touch locationInView:spinwhell];
        CGPoint prevLocation = [touch previousLocationInView:spinwhell];
        CGFloat xDist = (prevLocation.x - location.x);
        CGFloat yDist = (prevLocation.y - location.y);
        float angle = atan2f(xDist, yDist);
        angle=angle* 180 / 3.14;
        NSLog(@"Angle:%f",angle);

        if (angle==360)
        {
            totalrotation++;
            NSLog(@"Rotation:%d",totalrotation);
        }
        UIView *view = [self view];
        CGPoint center = CGPointMake(CGRectGetMidX([spinwhell bounds]), CGRectGetMidY([spinwhell bounds]));
        CGPoint currentTouchPoint = [touch locationInView:spinwhell];
        CGPoint previousTouchPoint = [touch previousLocationInView:spinwhell];
        CGFloat angleInRadians = atan2f(currentTouchPoint.y - center.y, currentTouchPoint.x - center.x) - atan2f(previousTouchPoint.y - center.y, previousTouchPoint.x - center.x);
//        NSLog(@"%f",angleInRadians);
        [self setRotation:angleInRadians];
            [self rotating:spinwhell];
    }
}
- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
    UITouch *touch = [touches anyObject];
    if (touch.view==spinwhell) 
    {
        CGPoint location = [touch locationInView:spinwhell];
        CGPoint prevLocation = [touch previousLocationInView:spinwhell];
        CGFloat distanceFromPrevious =[self GetDistance:location previouslocation:prevLocation];
        NSTimeInterval timeSincePrevious = event.timestamp - previousTimestamp;
        speed = distanceFromPrevious/timeSincePrevious;
        previousTimestamp = event.timestamp;
        NSLog(@"dist %f | time %f | speed %f",distanceFromPrevious, timeSincePrevious, speed);
        [[spinwhell layer]addAnimation:[self rotateanimation:speed] forKey:@"ClockWise"];
        [CATransaction  commit];
    }
}
-(CGFloat)GetDistance:(CGPoint)CurrPoint previouslocation:(CGPoint)prevPoint
{
    CGFloat xDist = (prevPoint.x - CurrPoint.x);
    CGFloat yDist = (prevPoint.y - CurrPoint.y);
    float angle = atan2f(xDist, yDist);
    angle=angle* 180 / 3.14;
    CGFloat distance;// = sqrt((xDist * xDist) + (yDist * yDist));
    distance=(3.14*168*angle)/180;
    if (distance<0)
    {
        distance*=-1;
    }
    return   distance;
}
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationLandscapeRight);
}

- (void)dealloc 
{
    [spinwhell release];
    [super dealloc];
}
@end
