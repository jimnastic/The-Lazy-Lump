//
//  RootViewController.h
//
//  Created by Darji Mehul iMobDev on 20/01/12.
//  Copyright (c) 2012 iMobDev Tech. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>

@interface RootViewController_ipad : UIViewController<UIGestureRecognizerDelegate>
{
    CABasicAnimation *animation;
    UISwipeGestureRecognizer *swipeLeftRecognizer;
	CGFloat lastRotation;
    int previousTimestamp;
    float speed;
    int totalrotation;
}
@property (nonatomic, assign) CGFloat rotation;
@property (retain, nonatomic) IBOutlet UIImageView *spinwhell;
-(id)rotateanimation:(float)timeDuration;                        //wheel rotation animation
-(id)Anticlockrotateanimation:(float)timeDuration;                        //wheel rotation animation
@property (nonatomic, retain) UISwipeGestureRecognizer *swipeLeftRecognizer;
- (void)addRotationGestureToView:(UIView *)view;
-(void)animation;
- (void)rotating:(id)recognizer;
-(CGFloat)GetDistance:(CGPoint)CurrPoint previouslocation:(CGPoint)prevPoint;

@end
